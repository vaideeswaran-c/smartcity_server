package com.myproject.mysmartcity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysmartcityApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysmartcityApplication.class, args);
	}

}
